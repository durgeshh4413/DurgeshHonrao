package StepDefinitions;

import io.cucumber.java.en.Given;
import pageObjects.Pages;

public class IPLPageTestStepdefinition {

    Pages pages = new Pages();

    @Given("^Fetch team name along with score$")
    public void Fetch_team_name_along_with_score() {

        pages.iPLPageTest().fetchTeamNameAlongWithScore();
    }

}
