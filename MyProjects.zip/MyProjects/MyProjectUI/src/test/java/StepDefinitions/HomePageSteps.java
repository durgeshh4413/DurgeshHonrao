package StepDefinitions;

import io.cucumber.java.en.And;
import org.testng.asserts.SoftAssert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Pages;

import java.io.IOException;

public class HomePageSteps {
    Pages pages = new Pages();
    SoftAssert softAssert = new SoftAssert();


    @Given("^Open browser and hit end point url$")
    public void open_browser_and_hit_end_point_url() {
        pages.homePage().hitApplicationURL();
    }

    @When("^Click on stats menu$")
    public void click_on_stats_menu() {
        pages.statsPage().clickOnStatslnk();
    }

    @And("^Accept cookies$")
    public void accept_cookies() {
        pages.statsPage().clickOnAcceptCookiesButton();
    }

    @Then("^Verify that Season tab is selected by default$")
    public void verify_that_season_tab_is_selecte_by_default() {
        softAssert.assertTrue(pages.statsPage().checkSeasonTabIsSelected(), "season tab is not selected by default");
        softAssert.assertAll();
    }

    @When("^Click on filter dropdown and select bowlers option$")
    public void click_on_filter_dropdown_and_select_bowlers_option() {
        pages.statsPage().clickOnFilterDropdown();
        pages.statsPage().clickOnBowlersDropdown();
        softAssert.assertTrue(pages.statsPage().verifyThatRadioButtonIsSelected());
        softAssert.assertAll();
        pages.statsPage().clickOnBestBowlingAverageOption();
    }

    @And("^Click on View All button and fetch player account$")
        public void click_On_view_all_button()  {
        pages.statsPage().click_on_viewAll_button();
        pages.statsPage().print_player_name();

    }

    @Then("^Check broken links$")
    public void check_broken_link() throws IOException {

        pages.homePage().checkBrokenLink();
    }
}
