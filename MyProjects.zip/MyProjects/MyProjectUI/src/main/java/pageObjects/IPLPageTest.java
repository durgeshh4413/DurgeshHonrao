package pageObjects;

import commonHelper.DriverFactory;
import commonHelper.DriverManager;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IPLPageTest {

    WebDriver driver;
    @FindBy(xpath = "//div[@class='ih-pt-ic ']//h2")
    List<WebElement> liTeamName;


    @FindBy(xpath = "//tr[@ng-repeat='list in pointsTableData']//td[starts-with(@class,'bt')]")
    List<WebElement> liPoints;


    IPLPageTest(){
        this.driver = DriverManager.getDriver();
        PageFactory.initElements(driver, this);
    }


    public void fetchTeamNameAlongWithScore(){
        driver.get("https://www.iplt20.com/points-table/men/2023");
        Map<String,String> map= new HashMap<>();
        for(int i=0;i<liTeamName.size();i++){
            map.put(liTeamName.get(i).getText(),liPoints.get(i).getText());
        }

        for(Map.Entry<String,String> entry : map.entrySet())
        {
            System.out.println("Team name : "+entry.getKey()+"Score point :   "+entry.getValue());
        }


        SoftAssert softAssert=new SoftAssert();
        softAssert.assertEquals(liTeamName.size(),10);
        softAssert.assertAll();

    }






}
