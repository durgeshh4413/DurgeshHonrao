package pageObjects;


public class Pages {


    private HomePage homePage;
    private StatsPage statsPage;

    private IPLPageTest iPLPageTest;



    public IPLPageTest iPLPageTest(){
        if (iPLPageTest == null) {
            iPLPageTest = new IPLPageTest();
        }
        return iPLPageTest;
    }
    public HomePage homePage() {
        if (homePage == null) {
            homePage = new HomePage();
        }
        return homePage;
    }

    public StatsPage statsPage() {
        if (statsPage == null) {
            statsPage = new StatsPage();
        }
        return statsPage;
    }


}