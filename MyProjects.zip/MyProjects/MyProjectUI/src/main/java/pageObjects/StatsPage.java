package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonHelper.DriverManager;
import utility.Utils;
import utility.Waits;

import java.util.List;

public class StatsPage {


    WebDriver driver;
    Pages pages;

    @FindBy(xpath = "//*[@id=\"myHeader\"]//ul[@class='site-menu main-menu js-clone-nav d-none d-lg-block textCenter']//a[@data-element_text='STATS']")
    private WebElement txtStats;

    @FindBy(xpath = "//button[@class='cookie__accept cookie__accept_btn']")
    private WebElement btnAcceptCookies;

    @FindBy(xpath = "//a[@class='np-recordtab__btn active statsContentTab seasonStats']")
    private WebElement tabSeason;

    @FindBy(xpath = "//button[@class='cookie__accept cookie__accept_btn']")
    private WebElement btnCookie;

    @FindBy(xpath = "//div[contains(text(),'Orange Cap') and @class='cSBDisplay ng-binding']")
    private WebElement drpdwnFilter;

    @FindBy(xpath = "//span[starts-with(@class,'cSBListFItems bowFItem')]")
    private WebElement rdoBowlers;

    @FindBy(xpath = "//div[@class='cSBList active']//div[text()='Best Bowling Average']")
    private WebElement txtBestBowlingAverage;

    @FindBy(xpath = "//div[@id='bowlingTAB']/div/a")
    private WebElement btnViewAll;

    @FindBy(xpath="//a[@class='st-ply']//div[starts-with(@class,'st-ply-name')]")
            private List<WebElement> liPlayerName;

    StatsPage() {
        this.driver = DriverManager.getDriver();
        PageFactory.initElements(driver, this);
    }

    public void clickOnStatslnk() {
        txtStats.click();
    }


    public boolean checkSeasonTabIsSelected() {
        //clickOnAcceptCookiesButton();
        Waits.waitForElementToBeClickable(driver, tabSeason, 60);
        Utils.scrollToElement(driver, tabSeason);
        if (tabSeason.getAttribute("class").contains("active"))
            return true;
        else
            return false;
    }

    public void clickOnFilterDropdown() {
        Utils.scrollToElement(driver, drpdwnFilter);
        Waits.waitForElementToBeClickable(driver, drpdwnFilter, 60);
        Utils.clickByJSExecutor(driver, drpdwnFilter);
        Utils.log.info("Clicked on dropdown filter");
    }

    public void clickOnAcceptCookiesButton() {
        btnAcceptCookies.click();
    }

    public void clickOnBowlersDropdown()  {

        Waits.waitForElementToBeClickable(driver, rdoBowlers, 60);
      Utils.scrollToElement(driver,drpdwnFilter);
        Utils.clickByJSExecutor(driver, rdoBowlers);
        Utils.log.info("Bowler radio button is selected");
    }

    public boolean verifyThatRadioButtonIsSelected() {
        return rdoBowlers.getAttribute("class").contains("selected");
    }

    public void clickOnBestBowlingAverageOption() {

        Utils.clickByJSExecutor(driver, txtBestBowlingAverage);
        Utils.log.info("Clicked on bowling average option");
    }

    public void click_on_viewAll_button(){
       Utils.scrollToElement(driver,btnViewAll);
        Utils.clickByJSExecutor(driver,btnViewAll);
        Utils.log.info("Clicked on view all button");
        Utils.log.info("count of player is :"+liPlayerName.size());
        int i=0;
        for(WebElement el:liPlayerName){
            i++;
            Utils.log.info("Player  number : "+i+" Player name :"+el.getText());
        }
    }
    public void print_player_name(){

    }

}
