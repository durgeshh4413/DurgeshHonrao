package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utility.Utils;
import utility.Waits;


import commonHelper.DriverManager;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class HomePage {

    WebDriver driver;
    Pages pages;

    @FindBy(xpath = "//button[@class='cookie__accept cookie__accept_btn']")
    private WebElement btnAcceptCookies;


    HomePage() {
        this.driver = DriverManager.getDriver();
        PageFactory.initElements(driver, this);
    }


    public void hitApplicationURL() {
        driver.get("https://www.iplt20.com/");
        Waits.waitForVisibilityOfElement(driver, btnAcceptCookies, 60);
        btnAcceptCookies.click();
        Utils.log.info("Clicked on cookies button");
    }

    public void checkBrokenLink() throws IOException {
        List<WebElement> links =
                driver.findElements(By.tagName("a"));

        // Printing The Total Links Number
        System.out.println("Total Link Size: " +
                links.size());
        for(int i = 0; i < links.size(); i++)
        {
            // Checking Each & Every Links
            WebElement element = links.get(i);

            String url = element.getAttribute("href");

            URL link = new URL(url);
            HttpURLConnection httpConn =
                    (HttpURLConnection) link.openConnection();
            httpConn.connect();

            // Getting The Response Code
            int code = httpConn.getResponseCode();

            if(code == 200)
            {
                System.out.println("valid Link: " +
                        url+ "Status code is : "+code);
            }
            else
            {
                System.out.println("invalid Link: " +
                        url+"Status code is : "+code);
            }
        }

        System.out.println();
        System.out.println("All Links Checked");

    }
}
