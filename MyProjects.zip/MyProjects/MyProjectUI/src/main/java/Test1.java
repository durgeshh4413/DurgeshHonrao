public class Test1 {

    //-1,-10,90,0,50,10,100
    public static void findSecondAndThirdHighestNumber(int[] arr){
    int temp;
        for(int i=0;i<arr.length;i++){
            for(int j=i+1;j<arr.length;j++){
                if(arr[i]>arr[j]){
                    temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        System.out.println("Third highest number is :"+arr[arr.length-3]);
        System.out.println("Second highest number is :"+arr[arr.length-2]);

    }

    public static void main(String[] args){

        int [] arr={-1,-10,90,0,50,10,100};

        Test1.findSecondAndThirdHighestNumber(arr);
    }
}
