package utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Waits {

    public static WebDriver driver;


    public static void waitForPageLoad(WebDriver driver, long time) {
        new WebDriverWait(driver, Duration.ofSeconds(time)).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
                .executeScript("return document.readyState").equals("complete"));
    }

    public static void waitForPageToBeInteractive(WebDriver driver, long time) {
        new WebDriverWait(driver, Duration.ofSeconds(time)).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
                .executeScript("return document.style.display").equals("none"));
    }


    public static void waitForPageToBeInteractive(WebDriver driver, WebElement element, long time) {
        new WebDriverWait(driver, Duration.ofSeconds(time)).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
                .executeScript("return arguments[0].style.display", element).equals("block"));
    }


    public static void fluentWait(WebDriver driver, WebElement element, long time) {

        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(time))
                .pollingEvery(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }


    public static void waitForElementToBeClickable(WebDriver driver, WebElement element, long time) {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(time));
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }


    public static void waitForvisibilityOfAllElementsLocatedBy(WebDriver driver, By element, long time) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(time));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
    }

    public static void waitForVisibilityOfElement(WebDriver driver, WebElement element, long time) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(time));
        wait.until(ExpectedConditions.visibilityOf(element));
    }
}