public class Test {



    public static void reverseString(char[] chrArr){
        int revIndex=chrArr.length-1;
        int i=0;

       // A#B%C
       while(i<revIndex){

           if(!Character.isAlphabetic(chrArr[i])){
               i++;
           }
           else if (!Character.isAlphabetic(chrArr[revIndex])){
               revIndex--;
           }
           else{
               char ch=chrArr[i];
               chrArr[i]=chrArr[revIndex];
               chrArr[revIndex]=ch;
               i++;
               revIndex--;
           }



       }

    }

    public static void main(String [] args){
        String str="A#B%C";
        char[] chrArray=str.toCharArray();
        Test.reverseString(chrArray);
        String rev=new String(chrArray);

        System.out.println(rev);


    }
}
