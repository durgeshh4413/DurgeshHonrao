package commonHelper;

public class Route {
    public final static String ADDPLACE="/maps/api/place/add/json";
}
