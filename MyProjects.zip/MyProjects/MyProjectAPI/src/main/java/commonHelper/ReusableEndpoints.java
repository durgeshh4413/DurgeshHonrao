package commonHelper;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.jsoup.Connection;

import java.util.Map;

import static io.restassured.RestAssured.given;

public class ReusableEndpoints {

    public static <T> Response postRequest(String basUri, Map<String, String> headerMap, T entity, String route) {
        RestAssured.reset();
        RestAssured.baseURI = basUri;
        return given().headers(headerMap).and().body(entity).when().post(route).then().log().all()
                .extract().response();

    }

    public static Response getRequest(String basUri, Map<String, String> headerMap, String route) {
        RestAssured.baseURI = basUri;
        return  given().headers(headerMap).and().body("").when().get(route).then().log().all().extract()
                .response();

    }
    public static Response deleteRequest(String basUri, Map<String, String> headerMap, String route) {
        RestAssured.reset();
        RestAssured.baseURI = basUri;
      return given().headers(headerMap).and().body("").when().delete(route).then().log().all().extract()
                .response();

    }
    public static <T> Response putRequest(String basUri, Map<String, String> headerMap, T entity, String route) {
        RestAssured.baseURI = basUri;

       return  given().headers(headerMap).and().body(entity).when().put(route).then().log().all().extract()
                .response();

    }

    public static <T> Response putuyRequest(String basUri, Map<String, String> headerMap, T entity, String route) {
        RestAssured.baseURI = basUri;

        return  given().headers(headerMap).and().body(entity).when().put(route).then().log().all().extract()
                .response();

    }


}
