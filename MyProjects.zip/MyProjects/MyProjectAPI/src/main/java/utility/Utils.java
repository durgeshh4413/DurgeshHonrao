package utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Utils {



    public static void loadPropertiesFile(Properties prop){

        FileInputStream input= null;
        try {
            input = new FileInputStream("C:\\Users\\Durgesh_Honrao\\Desktop\\backup framework\\MyProjects\\MyProjectAPI\\src\\main\\java\\config\\config.properties");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        try {
            prop.load(input);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
