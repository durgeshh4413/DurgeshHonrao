package pageObjects;


import com.google.gson.JsonArray;
import io.opentelemetry.exporter.logging.SystemOutLogExporter;
import io.restassured.path.json.JsonPath;
import org.apache.logging.log4j.core.util.JsonUtils;
import org.json.JSONObject;
import org.json.JSONArray;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class practiceComplexJson {

    public static void main(String[] args){
        String response1 = new String("{\"data\": [{\"MainId\": 1111,\"firstName\": \"Sherlock\",\"lastName\": \"Homes\",\"categories\": [{\"CategoryID\": 1,\"CategoryName\": \"Example\"}]},{\"MainId\": 122,\"firstName\": \"James\",\"lastName\": \"Watson\",\"categories\": [{\"CategoryID\": 2,\"CategoryName\": \"Example2\"}]}],\"messages\": [],\"success\": true}");

        JSONObject jObject  = new JSONObject(response1); // json
        JSONArray jsonArray = (JSONArray) jObject.get("data"); // get data object
       // String projectname = data.getString("name"); // get the name from data.

        String response=jObject.toString();

        System.out.println(response);
        System.out.println(jsonArray);

        for(int i=0;i< jsonArray.length();i++){

            if(jsonArray.getJSONObject(i).get("firstName").equals("Durgesh"))
            System.out.println(jsonArray.getJSONObject(i).get("firstName"));
        }

        Map<String,Object> map=jsonArray.getJSONObject(0).toMap();

        for(Map.Entry<String,Object> entry: map.entrySet())
                {
                    System.out.println("Key : "+entry.getKey()+" Value : "+entry.getValue()+"\n");
                }
    }

}
