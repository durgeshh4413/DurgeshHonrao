package pageObjects;


public class Pages {


    private GoogleMapPage googleMapPage;

    public GoogleMapPage googleMapPage() {
        if (googleMapPage == null) {
            googleMapPage = new GoogleMapPage();
        }
        return googleMapPage;
    }




}