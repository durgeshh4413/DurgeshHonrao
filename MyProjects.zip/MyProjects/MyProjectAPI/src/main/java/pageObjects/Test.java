package pageObjects;

public class Test {

    public static void printInRightAligned(String str){

        String []strArray=str.split(" ");
        int width=strArray[0].length();

        for(int i=1;i<strArray.length;i++){
            if(width<strArray[i].length()){
                    width=strArray[i].length();
            }
        }


        for(String str1:strArray){
            String rightAlignedString = String.format("%" + width + "s", str1);
            System.out.println(rightAlignedString);
        }
            }



    public static void main(String []args) {
        String xyz = "Chamberlain has a good workCulture";

        Test.printInRightAligned(xyz);


    }
}
