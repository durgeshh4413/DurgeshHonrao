package pageObjects;

import commonHelper.ReusableEndpoints;
import commonHelper.Route;
import io.restassured.response.Response;
import utility.Utils;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class GoogleMapPage {

    Properties properties = new Properties();
    FileInputStream input;
    Map<String,String> headers=new HashMap<>();

    GoogleMapPage(){


    }

    public void sendPostRequestToAddPlace(){
        Utils.loadPropertiesFile(properties);
        String baseURI= properties.getProperty("baseUrl");
        System.out.println("Base URL is : "+baseURI);
        String body="{\n" +
                "  \"location\": {\n" +
                "    \"lat\": -38.383494,\n" +
                "    \"lng\": 33.427362\n" +
                "  },\n" +
                "  \"accuracy\": 50,\n" +
                "  \"name\": \"Frontline house\",\n" +
                "  \"phone_number\": \"(+91) 983 893 3937\",\n" +
                "  \"address\": \"29, side layout, cohen 09\",\n" +
                "  \"types\": [\n" +
                "    \"shoe park\",\n" +
                "    \"shop\"\n" +
                "  ],\n" +
                "  \"website\": \"http://google.com\",\n" +
                "  \"language\": \"French-IN\"\n" +
                "}\n";
        Response response=ReusableEndpoints.postRequest(baseURI,headers,body, Route.ADDPLACE);
        System.out.println("response is :"+response.asString());
        System.out.println("response is :"+response.statusLine());
        //response.getBody().as


    }
}
