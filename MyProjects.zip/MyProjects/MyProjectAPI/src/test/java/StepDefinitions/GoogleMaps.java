package StepDefinitions;

import io.cucumber.java.en.And;
import org.testng.asserts.SoftAssert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Pages;

public class GoogleMaps {
    Pages pages = new Pages();
    SoftAssert softAssert = new SoftAssert();


    @Given("^Send post request to add place$")
    public void send_post_request_to_add_place() {
        pages.googleMapPage().sendPostRequestToAddPlace();
    }





}
